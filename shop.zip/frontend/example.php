<?php 

try {
	
} catch (Exception $e) {
	
}

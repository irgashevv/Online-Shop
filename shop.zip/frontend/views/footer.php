</div>
		<footer>
			<nav class="width1024">
				<div class="categories-group">
					<h4>Biography & True Stories</h4>
						<ul>
                            <li><a href="#">General</a></li>
							<li><a href="#">Diaries, Letters & Journals</a></li>
							<li><a href="#">Memoirs</a></li>
							<li><a href="#">True Stories</a></li>
							<li><a href="#">Generic Exams</a></li>
							<li><a href="#">GK Titles</a></li>
							<li><a href="#">Medical Entrance</a></li>
							<li><a href="#">Other Entrance Exams</a></li>
                            <li><a href="#">PG Entrance Examinations</a></li>
                            <li><a href="#">Self-help Titles</a></li>
                            <li><a href="#">Sociology</a></li>
						</ul>
				</div>
				<div class="categories-group">
					<h4>Professional & Reference</h4>
						<ul>
                            <li><a href="#">Academic and Reference</a></li>
							<li><a href="#">Business Trade</a></li>
							<li><a href="#">Engineering and Computer Science</a></li>
							<li><a href="#">Humanities, Social Sciences and Languages</a></li>
							<li><a href="#">Introduction to Computers</a></li>
							<li><a href="#">Science and Maths</a></li>
							<li><a href="#">Trade Business</a></li>
							<li><a href="#">English Language & Literature</a></li>
                            <li><a href="#">English Language Teaching</a></li>
                            <li><a href="#">Environment Awareness</a></li>
                            <li><a href="#">Environment Protection</a></li>
						</ul>
				</div>
				<div class="categories-group">
					<h4>Earth Sciences</h4>
						<ul>
							<li><a href="#">Earth Sciences</a></li>
							<li><a href="#">Geography</a></li>
							<li><a href="#">The Environment</a></li>
							<li><a href="#">Regional & Area Planning</a></li>
							<li><a href="#">Fantasy</a></li>
							<li><a href="#">Gay</a></li>
							<li><a href="#">Humorous</a></li>
							<li><a href="#">Interactive</a></li>
                            <li><a href="#">Legal</a></li>
                            <li><a href="#">Lesbian</a></li>
                            <li><a href="#">Men'S Adventure</a></li>
						</ul>
				</div>
				<div class="categories-group">
					<h4>Mathematics</h4>
						<ul>
							<li><a href="#">Algebra</a></li>
							<li><a href="#">Differential Equations</a></li>
							<li><a href="#">Discrete Mathematics</a></li>
							<li><a href="#">Fourier Analysis</a></li>
							<li><a href="#">Numerical Analysis</a></li>
							<li><a href="#">Probability</a></li>
							<li><a href="#">Statistical Methods/data Analysis</a></li>
							<li><a href="#">Stochastic And Random Processes</a></li>
                            <li><a href="#">Topology</a></li>
                            <li><a href="#">Statistics</a></li>
                            <li><a href="#">Mathematics</a></li>
						</ul>
				</div>
			</nav>
			<div id="payments-system">
				<div> We accept all major Credit Card/Debit Card/Internet Banking </div>
				<div>
                    <img src="http://localhost/shop/frontend/imgs/payments01.jpg" alt="">
                    <img src="http://localhost/shop/frontend/imgs/payments02.jpg" alt="">
                    <img src="http://localhost/shop/frontend/imgs/payments03.jpg" alt="">
                </div>
			</div>
				<div class="info">
					 Condition of Use Privacy Notice © 2012-2013, Books online, Inc. or its affiliates
				</div>
		</footer>
	</body>
</html>
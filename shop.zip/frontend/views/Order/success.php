<?php include_once __DIR__ . "/../header.php"; ?>

<div style="padding: 100px 0">
    <div style="font-size: 50px; text-align: center;">Поздравляем!</div>
        <div><br><br></div>
    <div style="text-align: center;">Вы успешно оформили заказ № <?=$orderId?>. Ожидайте, мы свяжемся с Вами!</div>
</div>

<?php include_once __DIR__ . "/../footer.php"; ?>